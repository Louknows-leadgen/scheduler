<?php namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ViciUser extends Model {

	protected $table = 'dci_vici_users';

}
