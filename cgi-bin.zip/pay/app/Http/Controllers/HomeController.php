<?php namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use DB;

class HomeController extends Controller {

	/*
	|--------------------------------------------------------------------------
	| Home Controller
	|--------------------------------------------------------------------------
	|
	| This controller renders your application's "dashboard" for users that
	| are authenticated. Of course, you are free to change or remove the
	| controller as you wish. It is just here to get your app started!
	|
	*/

	/**
	 * Create a new controller instance.
	 *
	 * @return void
	 */
	public function __construct()
	{
		$this->middleware('auth');
	}

	/**
	 * Show the application dashboard to the user.
	 *
	 * @return Response
	 */
	public function index(Request $request)
	{
		$payperiods = DB::table('payrolls')
			->select('payrolls.payperiod as value','payrolls.payperiod as label')
			->where('payrolls.payperiod','>=', '2018-07-10')
			->groupBy('payrolls.payperiod')
			->get();
		foreach($payperiods as $payprd){
			$periods[$payprd->value] = $payprd->label;
		}
		$payperiods = $periods;
		$data = $request->all();
		
		//* Once Payperiod is selected

		if(!empty($data)){
		$user = DB::table('payrolls')
			->select('payrolls.*','prlemployeemaster.hourlyrate','prlemployeemaster.taxstatusid','prlemployeemaster.employmenttype','prlemployeemaster.position', DB::raw('CONCAT(payrolls.last_name, ", ",payrolls.first_name) as name', 'prlemployeemaster.employeeid as empId'))
			->join('prlemployeemaster','prlemployeemaster.employeeid','=','payrolls.employee_id')
			->where('payrolls.payperiod', $data['payperiod'])
			->where('payrolls.employee_id', Auth::user()->employee_id)
			->first();
		}
		return view('home', compact('data','user','payperiods'));
	}

	public function payslip(Request $request){

		$data = $request->all();

		if(!empty($data)){

		$user = DB::table('payrolls')
			->select('payrolls.*','prlemployeemaster.hourlyrate','prlemployeemaster.taxstatusid','prlemployeemaster.employmenttype','prlemployeemaster.position',DB::raw('CONCAT(payrolls.last_name, ", ",payrolls.first_name) as name'))
			->join('prlemployeemaster','prlemployeemaster.employeeid','=','payrolls.employee_id')
			->where('payrolls.payperiod',$data['payperiod'])
			->where('payrolls.employee_id', Auth::user()->employee_id)
			->first();
		}
		
		return view('payslip', compact('data','user','payperiods'));

	}

	public function temp_payslip(Request $request){

		$payperiods = DB::table('payrolls')
			->select('payrolls.payperiod as value','payrolls.payperiod as label')
			->where('payrolls.payperiod','>=', '2018-07-10')
			->groupBy('payrolls.payperiod')
			->get();

		foreach($payperiods as $payprd){
			$periods[$payprd->value] = $payprd->label;
		}

		$payperiods = $periods;
		$data = $request->all();
		
		$user = DB::table('prlpaysummary')
			->select('prlpaysummary.*','prlemployeemaster.hourlyrate','prlemployeemaster.taxstatusid','prlemployeemaster.employmenttype','prlemployeemaster.position',DB::raw('CONCAT(prlemployeemaster.lastname, ", ",prlemployeemaster.firstname) as name, prlpaysummary.6thdayot AS sixthdayOT, 7thdayot AS seventhdayOT'))
			->join('prlemployeemaster','prlemployeemaster.employeeid','=','prlpaysummary.employeeid')
			->where('prlpaysummary.payperiod',"2019-1-25")
			->where('prlpaysummary.employeeid', Auth::user()->employee_id)
			->first();

		return view('payslip_temp', compact('data','user','payperiods'));
	}

	public function import(Request $request)
	{
		return view('import');
	}
}
