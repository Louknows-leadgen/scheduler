
<link href="{{ asset('css/bootstrap.css') }}" rel="stylesheet">

<link href="{{ asset('css/payslip.css') }}" rel="stylesheet">

<body style="background: url({{ asset('assets/dci-background.png') }});"> 

<?php 

/* List Variables */


$pay_date_period = date("Y-m-d");


//* Sample Value for display purposes just remove for  

$emp_id = $emp_name = $dept_name = $position = $basic_pay = $total_nd = $holiday_pay = $non_taxable_allowance = $non_taxable_allowance = $regular_ot = $taxable_allowance = $sixth_day_ot = $incentives = $seventh_day_ot = $disputes = $lates_or_absences = $load_deductions =  $phic = $withholding_tax = $hdmf = $taxable_income = $gross_income= $net_income = $sss= 1;

		/* Employee Information */


		$pay_date_period = isset($data['payperiod'])?$data['payperiod']:'';

		$emp_id 	= isset($user->employee_id)?$user->employee_id:'';

		$emp_name 	= isset($user->name)?$user->name:'';

		$dept_name 	= isset($user->position)?$user->position:'';

		$position  	= isset($user->position)?$user->position:'';

		/* EARNINGS */

  		$basic_pay 				= isset($user->basic_pay)?$user->basic_pay:'0.00';
	
		$total_nd 				= isset($user->total_nd)?$user->total_nd:'0.00';
 
		$adjustment_details 	= isset($user->manual_adjustment)?$user->manual_adjustment:'0.00';
				
		$holiday_pay 			= isset($user->holiday_pay)?$user->holiday_pay:'0.00';

		$non_taxable_allowance	= isset($user->total_non_tax_allowance)?$user->total_non_tax_allowance:'0.00';

  		$regular_ot 			= isset($user->regular_ot)?$user->regular_ot:'0.00';

		
		$sixth_day_ot			= isset($user->sixth_day_ot)?$user->sixth_day_ot:'0.00';

		$seventh_day_ot 		= isset($user->seventh_day_ot)?$user->seventh_day_ot:'0.00';

		$incentives 			= isset($user->incentive)?$user->incentive:'0.00';
		 
		$disputes 				= isset($user->disputes) ? $user->disputes:'0.00';

  		$taxable_allowance 		= isset($user->allowance)?$user->allowance:'0.00';

		/* DEDUCTIONS */

		$lates_or_absences = isset($user->deductions)?$user->deductions:'0.00';
		
		$sss = isset($user->sss)? $user->sss:'0.00';

		$loan_deductions =  isset($user->loan)? $user->loan:'0.00';

		$phic = isset($user->phic)?$user->phic:'0.00';
		
		$withholding_tax = isset($user->withold_tax)?$user->withold_tax:'0.00';
		
		$hdmf = isset($user->hdmf)?$user->hdmf:'0.00';
		
		$adjustment_details  = isset($user->manual_adjustment)?$user->manual_adjustment:'0.00';
 
		/* INCOME SUMMARY */

		$taxable_income = isset($user->total_tax_allowance)?$user->total_tax_allowance:'0.00';

		$gross_income = isset($user->gross_pay)?$user->gross_pay:'0.00';
		$net_income = isset($user->net_pay)?$user->net_pay:'0.00';

?>
		<table border="1" id= "emp_pay_summary-table" class="table center-table"> 

			<tr><td colspan="4" class=""> <h1> <b> Employee Pay Summary </h1>

			<tr><td id=  "payslip_date" colspan="4"> 

				<h3>  Payslip for Pay Period: <?php echo $pay_date_period; ?> </h3>

						<tr><td>Employee Id <td class="payslip_date-detail" > <?php echo $emp_id; ?> 
							<td>Employee Name <td class="payslip-detail"> <?php echo $emp_name; ?>

						<tr>
							<td> Department <td class="payslip-detail"> <?php echo $dept_name; ?> 
							<td> Position <td class="payslip-detail"> 	<?php echo $position; ?>

		</table>

		<table border="1" class="table center-table"> 

						<tr><td colspan="4" class="tbl-header"> <h2> <b> EARNINGS </h2>

						<tr><td>Basic Pay <td class="payslip-detail" > <?php echo $basic_pay; ?> 

							<td>Total ND  <td class="payslip-detail" > <?php echo $total_nd; ?>

						<tr>
							<td>Holiday Pay <td class="payslip-detail"><?php echo $holiday_pay; ?> 
							
							<td> Non- taxable Allowance 
								<td class="payslip-detail"> <?php echo $non_taxable_allowance; ?>

						<tr><td >Regular OT

							<td class="payslip-detail"> <?php echo $regular_ot; ?> 

							<td> Taxable Allowance <td class="payslip-detail"> 
														<?php echo $taxable_allowance; ?>

						<tr><td > 6th Day OT 
							<td class="payslip-detail"> <?php echo $sixth_day_ot; ?> <td> Incentives <td class="payslip-detail"> <?php echo $incentives; ?>
						<tr>
							<td> 7th Day OT <td class="payslip-detail"> <?php echo $seventh_day_ot; ?> 
							<td> Disputes <td class="payslip-detail"> <?php echo $disputes; ?>
			 
					</table>

		<table border="1" class="table center-table"> 

						<tr><td colspan="4" class="tbl-header"> <h2> <b> DEDUCTIONS </h2>

						<tr><td>Late/Absences/Others 
							<td class="payslip-detail"><?php echo $lates_or_absences; ?> 
							<td> SSS <td  class="payslip-detail"> <?php echo $sss; ?>

						<tr><td >Load Deductions 	 <td  class="payslip-detail">  
							<?php echo $loan_deductions; ?> <td > PHIC 
							<td class="payslip-detail"> <?php echo $phic; ?>

						<tr><td >Witholding Tax <td  class="payslip-detail">  
							<?php echo $withholding_tax; ?> 
							<td > HDMF <td> <?php echo $hdmf; ?>

						<tr><td> Adjustment Details <td colspan="3"> <?php $adjustment_details; ?> 
			 
					</table>

					<table border="1" width="40%" class="table pull-left" id = "income_summary"> 

						<tr>
							<td> Taxable Income 
							<td class="payslip-detail"> <?php echo $taxable_income; ?> 

							<tr>
							<td> <b> Gross Income </b>
							<td class="payslip-detail">  <?php echo $gross_income; ?>  
							
							<tr><td> <b> Net Income </b> 
							<td class="payslip-detail">  <?php echo $net_income; ?>  
	
					</table>
	</center>

</body>
