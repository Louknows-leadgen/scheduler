@extends('app')

@section('content')
	{{$masterlist | json}}
@endsection