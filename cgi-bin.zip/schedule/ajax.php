<?
include('db_connect.php');
$transferthis=$_POST['totransfer'];
foreach($transferthis as $t){
	echo $t.'<br />';
mysql_query("insert into teamassignment (teamlead,employeeid) values ('".$_POST['TL']."','".$t."')");
}
	?>