<?
include('db_connect.php');
if($_POST['add']){
	$supervisor=$_POST['supervisor'];
	$password = "password";
	mysql_query("insert into team_supervisor(TeamSupervisor) values('".$supervisor."')");
	$result = mysql_query("SELECT * from team_supervisor WHERE TeamSupervisor = '".$supervisor."' ");
	$row = mysql_fetch_array($result);
	mysql_query("insert into userlogin(Username, Password, Level, Name, employeeid) values('".$_POST['username']."', '".$password."','".$_POST['support']."','".$supervisor."','".$row['id']."')");
	mysql_query("UPDATE team_supervisor set employeeid = '".$row['id']."' WHERE id = '".$row['id']."'");

 	 $sqllog="INSERT INTO prlemplog (Username, ipaddress, description)
     VALUES
     ('".$_SESSION['Username']."','".$_SERVER['REMOTE_ADDR']."', 'Added new supervisor ".$_POST['username']."')";	
	 mysql_query($sqllog);
	
	}
if($_GET['task']=='delete'){
	mysql_query("delete from team_supervisor where id='".$_GET['id']."'");
	mysql_query("delete from userlogin where employeeid='".$_GET['id']."'");
	
 	 $sqllog="INSERT INTO prlemplog (Username, ipaddress, description)
     VALUES
     ('".$_SESSION['Username']."','".$_SERVER['REMOTE_ADDR']."', 'Deleted supervisor ".$_GET['id']."')";	
	 mysql_query($sqllog);	
	}
if($_GET['task']=='change'){
	
	if($_GET['level']=="N")
	{
		$level = '4';
	}
	else
	{
		$level = '2';
	}	
	mysql_query("UPDATE userlogin SET Level = '".$level."' where employeeid='".$_GET['id']."'");
	
 	 $sqllog="INSERT INTO prlemplog (Username, ipaddress, description)
     VALUES
     ('".$_SESSION['Username']."','".$_SERVER['REMOTE_ADDR']."', 'Change To Support Group ".$_GET['id']."')";	
	 mysql_query($sqllog);	
	}	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>

<style type="text/css">
<!--
body,td,th {
	font-family: Verdana, Geneva, sans-serif;
	font-size: 12px;
}
-->
</style></head>

<body>
<p style="background-color:#CCC; font-size:14px"><strong>&nbsp;Add Supervisor</strong></p>

<form method="post">
  <p>Name of supervisor:
  <input name="supervisor" />
  </p>
  <p>Supervisor Log In Username:
    <input name="username" />
  (password will default to password)</p>
  <p>Support Group(Y/N): 
  <select name="support">
  <option value="2">No</option>
  <option value="4">Yes</option>
  </select></p>
  <p>
    <input type="submit" name="add" value="Add" />
  </p>
</form>
<br />

<table border="1" cellpadding="5">
<tr>
<td><strong> ID</strong></td>
<td><strong>Supervisor Name</strong></td>
<td align = "center"><strong>Support Group(Y/N)</strong></td>
<td><strong>Delete</strong></td>
</tr>
<?
$getlist=mysql_query("select * from team_supervisor");
while($rowlist=mysql_fetch_array($getlist))
{
	$getlevel=mysql_query("select * from userlogin WHERE employeeid = '".$rowlist['id']."'");
	$rowlevel=mysql_fetch_array($getlevel);
	if($rowlevel['Level']=='2')
	{
		$level = "N";
	}
	else if($rowlevel['Level']=='4')
	{
		$level = "Y";
	}
?>
  <tr>
    <td><?=$rowlist['id']?></td>
    <td><?=$rowlist['TeamSupervisor']?></td>
    <td align="center">(<?=$level?>) <a href="addSupervisor.php?task=change&id=<?=$rowlist['id']?>&level=<?=$level?>">click to change</a></td>
    <td align="center"><a href="addSupervisor.php?task=delete&id=<?=$rowlist['id']?>"><img src="images/close.png" width="18" border="0" /></a></td>
  </tr>
<?
}
?>
</table>

</body>
</html>