<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Cane Events</title>
<!-- <link type="image/x-icon" href="images/heart.ico" rel="shortcut icon"/> -->

<link rel="stylesheet" type="text/css" href="style.css"/>
	
	<script type="text/javascript" src="jquery.js"></script>
	<script type="text/javascript" src="jquery-color.js"></script>
	<script type="text/javascript" src="main.js"></script>


    <script type="text/javascript">
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>

		<link href="style.css" rel="stylesheet" type="text/css">



</head>
<style>body{
background-color:#303a3c;
 font-size:11px;
}</style>
<body onload="MM_preloadImages('images/sign-in pink.png','images/signup-64 pink.png')">
<table border="0" cellspacing="0" cellpadding="0" width="750" align="center">
<?php include("header.php"); ?>

<!--<Tr><td></td><td><form name="form1" method="post" action="">
Username:<input type="text" name="username"  />
Password:<input type="password" name="password" />
<input type="submit" name="login" value="Login" />
</form></td></Tr> -->

<TR><TD colspan="2" style="padding-bottom:5px;" >


	<table cellpadding="0" cellspacing="0" style="padding-top:10px;">
	<TR><TD >
		<table cellpadding="0" cellspacing="0" height="100%">
			<TR><TD colspan="2" ><img src="images/topbox2.jpg"></TD></TR>
			<TR><TD style="background-image:url('images/leftbox.jpg');background-repeat: repeat; width:9px; ">&nbsp;</TD>
			
			
			<td bgcolor="#cecece" valign="top">

<!-- main contents here -->

	<iframe name="iframe2" src="viewcalendar.php" width="730" scrolling="no" frameborder="0" height="500"></iframe>
<!-- end main contents -->				</td></TR>
			<tr><TD style="background-image:url('images/leftboxbottom.jpg');background-repeat: repeat; width:9px; ">&nbsp;</TD><td bgcolor="#cecece" height="2">&nbsp;</td></TR>
		</table>
		
	      </TD>
		
		
<!--<Td bgcolor="#262626" width="320" valign="top">
		<table cellpadding="0" cellspacing="0" style="padding-top:10px" align="center" width="300"><TR><TD ><font class="title">Events:</font></TD></TR>
		<tr>
			<TD  align="center">
				<img src="images/hobcon.jpg" width="280" style=" border:3px solid white;">			</TD>
		</tr>
	</table>
	<table cellpadding="3" cellspacing="0" style="padding-top:7px" align="center" width="300"><TR><TD><font class="title">Sponsors:</font></TD></TR>
			
			<tr valign="center">
			<td align="center"> 
		<iframe width="206" height="206" scrolling="no" frameborder="0"  src="slideshow.php" ></iframe>				</TD>
			</tr>
	</table>

	<table cellpadding="3" cellspacing="0" style="padding-top:7px" align="center" width="300"><TR><TD><font class="title">Live Chat:</font></TD></TR>
			
			<tr valign="center">
			<td align="center"> 
		<object type="application/x-shockwave-flash" data="http://www.99chats.com/chat.swf?r=10708" width="280" height="280"><param name="movie" value="http://www.99chats.com/chat.swf?r=10708" /><param name="bgcolor" value="#ffcccc" /><embed src="http://www.99chats.com/chat.swf?r=10708" type="application/x-shockwave-flash" width="280" height="280" bgcolor="#ffcccc"></embed><br><a href="http://www.kusuricenter.com/">バイアグラ</a> <a href="http://www.99chats.com/">Chats</a></object>				</TD>
			</tr>
	</table>		</Td>
	</TR></table>


</TD>!-->
</TR>
<tr ><TD colspan="2" style="background-image:url('images/trial.jpg');background-repeat: repeat; hieght:4px; " ><img src="images/trial.jpg"></TD></tr>
<tr ><TD colspan="2" >CopyRights All Rights Reserved 2009</TD></tr>
</table>
</body>
</html>
