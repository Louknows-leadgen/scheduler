<style type="text/css">
<!--
body,td,th {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
}
img{
border:0;}
-->
</style>
<?
include("db_connect.php");
if($_POST['shiftname']!='')
{
	$groupschedulename=$_POST['shiftname'];
	$starttime=$_POST['shiftstarthour'].":".$_POST['shiftstartmin'].":00";
	$lunchstarting=$_POST['lunchstarthour'].":".$_POST['lunchstartmin'].":00";
	$lunchhour = $_POST['lunchstarthour'] + 1;
	$lunchending=$lunchhour.":".$_POST['lunchstartmin'].":00";
	$endtime=$_POST['shiftendhour'].":".$_POST['shiftendmin'].":00";
	$prelunch = $_POST['lunchstarthour'] - $_POST['shiftstarthour'] ;
	if($prelunch< 0 )
	{
		$prelunch = $prelunch + 24;
	}
	$prelunchmin = $_POST['lunchstartmin']/60;
	$prelunch = $prelunch.".".$prelunchmin;
	
	$Mon=$_POST['Mon']; 
	$Tue=$_POST['Tue']; 
	$Wed=$_POST['Wed']; 
	$Thu=$_POST['Thu']; 
	$Fri=$_POST['Fri']; 
	$Sat=$_POST['Sat']; 
	$Sun=$_POST['Sun']; 
	$Holiday=$_POST['Holiday'];
	$updatesched="update groupschedule set groupschedulename='$groupschedulename',
	starttime='$starttime',
	endtime='$endtime', 
	lunchstart='$lunchstarting',
	lunchend='$lunchending',
	prelunch='$prelunch', 
	Mon='$Mon', 
	Tue='$Tue', 
	Wed='$Wed', 
	Thu='$Thu', 
	Fri='$Fri', 
	Sat='$Sat', 
	Sun='$Sun', 
	Holiday='$Holiday' where id='".$_POST['id']."'";
	//echo $updatesched;
	mysql_query($updatesched);

$mess='<p style="background-color:yellow; font-size:14px; color:Black""><b>'.$groupschedulename.' Successfully Updated</b></p>';
	
}

if($_GET['task']=="deletesched")
{

	mysql_query("DELETE FROM groupschedule WHERE id = '".$_GET['schedid']."'");
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>VectorBPO Payroll> View Schedule</title>
<link rel="stylesheet" type="text/css" href="css/styles.css" />


</head>

<body>
<font style="background-color:#FF3;color:#000; size:14px;"><?=$mess?></font>

<table border="1" cellpadding="3" bgcolor="#FFFFFF">
<td colspan="13" class="pagetitle"> <div align="center"><strong>View/Edit/Delete Schedule</strong></div></td>
<tr>
	<td>Shift Name</td><td>Time Start</td><td>Lunch Start</td><td>Lunch End</td><td>Time End</td>
    <td>Mon</td>
    <td>Tue</td> 
    <td>Wed</td>
    <td>Thu</td>
    <td>Fri</td>	
    <td>Sat</td> 
    <td>Sun</td>	 
    <td>Holiday</td>	 	 	 	 	
	<td>Edit</td>
	<td>Delete</td>
</tr>
<?
$getgroupsched=mysql_query("SELECT * FROM groupschedule ORDER BY groupschedulename asc");
while($rowsched=mysql_fetch_array($getgroupsched)){
?>
<tr>
	<td align="center"><?=$rowsched['groupschedulename']?></td>
    <td><?=$rowsched['starttime']?></td>
    <td><?=$rowsched['lunchstart']?></td>
    <td><?=$rowsched['lunchend']?></td>
    <td><?=$rowsched['endtime']?></td>
    <td><input type="checkbox"  <? if($rowsched['Mon']=='1'){ echo 'checked="checked"';} ?> name="Mon" disabled="disabled"/></td>
    <td><input type="checkbox" disabled="disabled" <? if($rowsched['Tue']=='1'){ echo 'checked="checked"';} ?> /></td> 
    <td><input type="checkbox" disabled="disabled" <? if($rowsched['Wed']=='1'){ echo 'checked="checked"';} ?> /></td>
    <td><input type="checkbox" disabled="disabled" <? if($rowsched['Thu']=='1'){ echo 'checked="checked"';} ?> /></td>
    <td><input type="checkbox" disabled="disabled" <? if($rowsched['Fri']=='1'){ echo 'checked="checked"';} ?> /></td>	
    <td><input type="checkbox" disabled="disabled" <? if($rowsched['Sat']=='1'){ echo 'checked="checked"';} ?> /></td> 
    <td><input type="checkbox" disabled="disabled" <? if($rowsched['Sun']=='1'){ echo 'checked="checked"';} ?> /></td>	 
    <td><input type="checkbox" disabled="disabled" <? if($rowsched['Holiday']=='1'){ echo 'checked="checked"';} ?></td>
    <td align="center"><a href="?task=editsched&schedid=<?=$rowsched['id']?> alt="Edit" name="Edit""><img src="images/document_edit.png" width="20"  /></a></td>
    <td align="center"><a href="?task=deletesched&schedid=<?=$rowsched['id']?>" alt="Delete" name="Delete"><img src="images/close.png" width="20"  /></a></td>
</tr>
<?
}
?>
</table>

<?
if($_GET['task']=='editsched')
{
$getsched="select * from groupschedule where id='".$_GET['schedid']."'";
//echo $getsched;
$getsched=mysql_query($getsched);
while($rowsched=mysql_fetch_array($getsched)){
$rowstarttime=explode(":",$rowsched['starttime']);
$lunchstarttime=explode(":",$rowsched['lunchstart']);
$rowendtime=explode(":",$rowsched['endtime']);
//echo $rowsched['groupschedulename'];
	?>
	<form action="viewsched.php" method="post">
    <input type="hidden" name="id" value="<?=$rowsched['id']?>" />
	<table border="0" bgcolor="#FFFFFF">
	  <tr>
		<td>Shift Name:</td>
		<td><input type="text" name="shiftname" value="<?=$rowsched['groupschedulename']?>" /></td>
	  </tr>
	  <tr>
		<td>Shift Start:</td>
		<td>
			<select name="shiftstarthour" />
			<?
			for($x=0;$x<25;$x++){
				if($x<10){ $x="0".$x; }
			?>
				<option <? if($rowstarttime[0]==$x) { echo 'selected="selected"';} ?>><?  echo $x; ?></option>
			<?
			}
			?>
			</select>
			<select name="shiftstartmin">
				<option <? if($rowstarttime[1]=='00') { echo 'selected="selected"';} ?>>00</option>
				<option <? if($rowstarttime[1]=='15') { echo 'selected="selected"';} ?>>15</option>
				<option <? if($rowstarttime[1]=='30') { echo 'selected="selected"';} ?>>30</option>
				<option <? if($rowstarttime[1]=='45') { echo 'selected="selected"';} ?>>45</option>
			</select>
		</td>
        <tr>
		<td>Lunch Start:</td>
		<td>
			<select name="lunchstarthour" />
			<?
			for($x=0;$x<25;$x++){
				if($x<10){ $x="0".$x; }
			?>
				<option <? if($lunchstarttime[0]==$x) { echo 'selected="selected"';} ?>><?  echo $x; ?></option>
			<?
			}
			?>
			</select>
			<select name="lunchstartmin">
				<option <? if($lunchstarttime[1]=='00') { echo 'selected="selected"';} ?>>00</option>
				<option <? if($lunchstarttime[1]=='15') { echo 'selected="selected"';} ?>>15</option>
				<option <? if($lunchstarttime[1]=='30') { echo 'selected="selected"';} ?>>30</option>
				<option <? if($lunchstarttime[1]=='45') { echo 'selected="selected"';} ?>>45</option>
			</select>
		</td>        
	  </tr>
	  <tr>
		<td>Shift End:</td>
		<td>
        <select name="shiftendhour" />
			<?
			for($x=0;$x<25;$x++){
				if($x<10){ $x="0".$x; }
			?>
				<option <? if($rowendtime[0]==$x) { echo 'selected="selected"';} ?>><?  echo $x; ?></option>
			<?
			}
			?>
			</select>
			<select name="shiftendmin">
				<option <? if($rowendtime[1]=='00') { echo 'selected="selected"';} ?>>00</option>
				<option <? if($rowendtime[1]=='15') { echo 'selected="selected"';} ?>>15</option>
				<option <? if($rowendtime[1]=='30') { echo 'selected="selected"';} ?>>30</option>
				<option <? if($rowendtime[1]=='45') { echo 'selected="selected"';} ?>>45</option>
			</select>
	  </td>
	  </tr>
	   <tr>
		<td></td>
		<td>
			<input type="checkbox" name="Mon" value="1" <? if($rowsched['Mon']=='1') { echo 'checked="checked"';} ?>  /> Mon  
			<input type="checkbox" name="Tue" value="1" <? if($rowsched['Tue']=='1') { echo 'checked="checked"';} ?>  /> Tue  
			<input type="checkbox" name="Wed" value="1" <? if($rowsched['Wed']=='1') { echo 'checked="checked"';} ?>  /> Wed  
			<input type="checkbox" name="Thu" value="1" <? if($rowsched['Thu']=='1') { echo 'checked="checked"';} ?>  /> Thu  
			<input type="checkbox" name="Fri" value="1" <? if($rowsched['Fri']=='1') { echo 'checked="checked"';} ?>  /> Fri  
			<input type="checkbox" name="Sat" value="1" <? if($rowsched['Sat']=='1') { echo 'checked="checked"';} ?>  /> Sat  
			<input type="checkbox" name="Sun" value="1" <? if($rowsched['Sun']=='1') { echo 'checked="checked"';} ?>  /> Sun  
			<input type="checkbox" name="Holiday" value="1" <? if($rowsched['Holiday']=='1') { echo 'checked="checked"';} ?>  /> Holiday  
		
		</td>
	  </tr>
	  <tr>
		<td>&nbsp;</td>
		<td><input type="submit" name="Update Schedule" value="Update Schedule"></td>
	  </tr>
	 
	</table>
	</form>
	<?
	}
}


?>
</body>
</html>
