<style type="text/css">
<!--
body,td,th {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
}
img{
border:0;}
-->
</style><?php 
if($_GET['todo']== '10')
{
$con = mysql_connect("localhost","digicono_HRadmin","DigiC0n0nlin3!");
	if (!$con)
	  {
	  die('Could not connect: ' . mysql_error());
	  }
	
	mysql_select_db("digicono_hris", $con);
?>
<p>Tax Table Rate For Semi-Monthly</p>
<table width="" border="0">
  <tr align="center">
    
<?php    
         $ctr = '0';
        $result = mysql_query("SELECT taxstatusid, percentofexcessamount, fixtax, rangeto from prltaxtablerate GROUP BY percentofexcessamount ORDER BY rangeto ASC");
        while($row = mysql_fetch_array($result))
		{
         $excess = $row['percentofexcessamount'];
           if ($ctr == '0')
		    {
?>		  
      <td width="90">
        <table width="" border="1">		
           <tr>
             <td width="80" align = "center">&nbsp;</td>
          </tr>
           <tr>
             <td align = "center"><strong>FA</strong></td>
          </tr>
           <tr>
             <td align = "center"><strong>%</strong></td>
          </tr>
<?php        
           $resultpud = mysql_query("SELECT rangefrom, percentofexcessamount,taxstatusid from prltaxtablerate 
									WHERE percentofexcessamount = $excess ORDER BY rangefrom ASC");
           while($rowsad = mysql_fetch_array($resultpud))
		         {					
				   echo "<tr align = 'center'><td width='80'>";
				   echo "<strong>";
				   echo "$rowsad[taxstatusid]";
				   echo "</strong></td></tr>";
				 }
			echo "</table>";
			echo "</td>";
			}
		 $ctr = $ctr + '1';    
?>		 
    <td width="90">

        <table width="" border="1">
           <tr align = "top">
             <td width="80" align = "center"><strong><?php echo $ctr;?></strong></td>
            </tr>
           <tr align = "right">
             <td width="80"><?php echo $row['fixtax'];?></td>
            </tr>
           <tr align = "right">
             <td width="80"><?php echo $row['percentofexcessamount'];?></td>
            </tr>
            
<?php		
           $resultpud = mysql_query("SELECT rangefrom, percentofexcessamount from prltaxtablerate 
									WHERE percentofexcessamount = $excess ORDER BY rangefrom ASC");
           while($rowsad = mysql_fetch_array($resultpud))
		         {					
				   echo "<tr align = 'top'><td width='80'>";
				   echo "$rowsad[rangefrom]";
				   echo "</td></tr>";
				 }
?>  
             
         </table>

    </td>
    

    
<?php    }
	
?>
</table>
<?php

}

?>

